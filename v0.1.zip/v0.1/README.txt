Rus:
Для корректной работы программы сначала надо создать coockie для входа в аккаунт стим. 
1. Запустите Settings.exе, введите логин и пароль.
2. Нажмите кнопку Save login settings
2. Пройдите полную авторизацию в аккаунт.
3. В настройках профиля стим добавьте витрину "Поле со своей информацией" (иначе программа работать не будет)
4. Затем нажмите кнопку Test script

Для автоматической смены картинки при запуске системы: 
1. Cоздайте ярлык для файла forAutomaticStart.exe. 
2. Нажмите win+r и введите shell:startup, скопируйте ярлык в эту папку.

Для того, чтобы добавить собственные рисунки, создавайте файл расширения .txt и добавьте со следующим порядковым номером.

Eng:
For the program to work correctly, you first need to create a cookie to log into your Steam account.
1. Run Settings.exe, enter your login and password.
2. Click the Save login settings button
2. Completely log into your account.
3. In the Steam profile settings, add the "Field with your information" showcase (otherwise the program will not work)
4. Then click the Test script button

To automatically change the picture when the system starts:
1. Create a shortcut for the forAutomaticStart.exe file.
2. Press win+r and enter shell:startup, copy the shortcut to this folder.

To add your own images, create a .txt file and add it with the next serial number.